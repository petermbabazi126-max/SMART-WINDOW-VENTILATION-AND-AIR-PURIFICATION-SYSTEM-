#include <Wire.h>
#include <LiquidCrystal_I2C.h>
#include <DHT.h>
#include <IRremote.h>
#include <Servo.h>

// ================= PIN DEFINITIONS =================
#define DHTPIN 6
#define DHTTYPE DHT11

#define MQ135_OUT A0   // Outside air
#define MQ135_IN  A1   // Inside air

#define RELAY_INFILL 7
#define RELAY_EXFILL 8

#define IR_PIN 3
#define SERVO_PIN 5

#define BTN_NEXT 9
#define BTN_PREV 10

// ================= OBJECTS =================
DHT dht(DHTPIN, DHTTYPE);
LiquidCrystal_I2C lcd(0x27, 16, 2);
Servo windowServo;

// ================= STATES =================
bool autoMode = true;
bool windowOpen = false;
bool infillFan = false;
bool exfillFan = false;

// ================= PAGE SYSTEM =================
int currentPage = 0;
const int totalPages = 4;

bool lastNextState = HIGH;
bool lastPrevState = HIGH;

unsigned long lastButtonTime = 0;
const unsigned long debounceDelay = 180;

// ================= THRESHOLD RANGES =================
int airLowPct = 37;
int airHighPct = 43;

float tempLow = 27.0;
float tempHigh = 33.0;

float humidityThreshold = 70.0;

// ================= IR BUTTON CODES =================
#define BTN_AUTO   0xE916FF00
#define BTN_MANUAL 0xF30CFF00
#define BTN_WINDOW 0xE718FF00
#define BTN_INFILL 0xA15EFF00
#define BTN_EXFILL 0xF708FF00

// ================= AIR SENSOR CALIBRATION =================
// INSIDE SENSOR
int airInMin = 55;
int airInMax = 230;

// OUTSIDE SENSOR
int airOutMin = 82;
int airOutMax = 710;

// ================= SENSOR VALUES =================
float temp = 0.0;
float hum = 0.0;
int airInRaw = 0;
int airOutRaw = 0;
int airInPct = 0;
int airOutPct = 0;

// ================= SERVO SMOOTH CONTROL =================
int servoCurrentPos = 0;
int servoTargetPos = 0;

unsigned long lastServoStepTime = 0;
const unsigned long servoStepInterval = 30; // slower, more realistic motion

// ================= TASK TIMING =================
unsigned long lastSensorRead = 0;
unsigned long lastLCDUpdate = 0;
unsigned long lastSerialUpdate = 0;

const unsigned long sensorInterval = 800;
const unsigned long lcdInterval = 250;
const unsigned long serialInterval = 1000;

// ================= MODE MESSAGE =================
bool showModeMessage = false;
String modeMessage = "";
unsigned long modeMessageStart = 0;
const unsigned long modeMessageDuration = 1200;

// ================= LCD TRACKING =================
int lastDisplayedPage = -1;

// ================= SETUP =================
void setup() {
  Serial.begin(9600);

  pinMode(RELAY_INFILL, OUTPUT);
  pinMode(RELAY_EXFILL, OUTPUT);

  pinMode(BTN_NEXT, INPUT_PULLUP);
  pinMode(BTN_PREV, INPUT_PULLUP);

  // ACTIVE HIGH RELAY LOGIC: LOW = OFF, HIGH = ON
  digitalWrite(RELAY_INFILL, LOW);   
  digitalWrite(RELAY_EXFILL, LOW);

  IrReceiver.begin(IR_PIN, ENABLE_LED_FEEDBACK);
  dht.begin();

  lcd.init();
  lcd.backlight();

  windowServo.attach(SERVO_PIN);
  servoCurrentPos = 0;
  servoTargetPos = 0;
  windowServo.write(servoCurrentPos);
  windowOpen = false;

  lcd.setCursor(0, 0);
  lcd.print("System Init...");
  lcd.setCursor(0, 1);
  lcd.print("Please wait");
  delay(1200);
  lcd.clear();
}

// ================= WINDOW CONTROL =================
void openWindow() {
  windowOpen = true;
  servoTargetPos = 90;
}

void closeWindow() {
  windowOpen = false;
  servoTargetPos = 0;
}

void updateServoTask() {
  unsigned long now = millis();

  if (now - lastServoStepTime >= servoStepInterval) {
    lastServoStepTime = now;

    if (servoCurrentPos < servoTargetPos) {
      servoCurrentPos++;
      windowServo.write(servoCurrentPos);
    }
    else if (servoCurrentPos > servoTargetPos) {
      servoCurrentPos--;
      windowServo.write(servoCurrentPos);
    }
  }
}

// ================= FAN CONTROL =================
void setInfill(bool state) {
  infillFan = state;
  digitalWrite(RELAY_INFILL, state ? HIGH : LOW);
}

void setExfill(bool state) {
  exfillFan = state;
  digitalWrite(RELAY_EXFILL, state ? HIGH : LOW);
}

// ================= MAP AIR SENSOR =================
int mapAirQuality(int rawValue, int minVal, int maxVal) {
  int percent = map(rawValue, minVal, maxVal, 0, 100);
  if (percent < 0) percent = 0;
  if (percent > 100) percent = 100;
  return percent;
}

// ================= MODE POPUP =================
void triggerModeMessage(const String &msg) {
  modeMessage = msg;
  showModeMessage = true;
  modeMessageStart = millis();
  lcd.clear();
  lastDisplayedPage = -1;
}

// ================= IR HANDLER =================
void handleIR() {
  if (IrReceiver.decode()) {
    unsigned long code = IrReceiver.decodedIRData.decodedRawData;
    Serial.print("IR Code: 0x");
    Serial.println(code, HEX);

    if (code == BTN_AUTO) {
      if (!autoMode) {
        autoMode = true;
        triggerModeMessage("MODE: AUTO");
      }
    }
    else if (code == BTN_MANUAL) {
      if (autoMode) {
        autoMode = false;
        triggerModeMessage("MODE: MANUAL");
      }
    }

    if (!autoMode) {
      if (code == BTN_WINDOW) {
        windowOpen ? closeWindow() : openWindow();
      }
      else if (code == BTN_INFILL) {
        setInfill(!infillFan);
      }
      else if (code == BTN_EXFILL) {
        setExfill(!exfillFan);
      }
    }

    IrReceiver.resume();
  }
}

// ================= BUTTON NAVIGATION =================
void handleButtons() {
  bool nextState = digitalRead(BTN_NEXT);
  bool prevState = digitalRead(BTN_PREV);
  unsigned long now = millis();

  if (lastNextState == HIGH && nextState == LOW) {
    if (now - lastButtonTime > debounceDelay) {
      currentPage++;
      if (currentPage >= totalPages) currentPage = 0;
      lastButtonTime = now;
      lastDisplayedPage = -1;
    }
  }

  if (lastPrevState == HIGH && prevState == LOW) {
    if (now - lastButtonTime > debounceDelay) {
      currentPage--;
      if (currentPage < 0) currentPage = totalPages - 1;
      lastButtonTime = now;
      lastDisplayedPage = -1;
    }
  }

  lastNextState = nextState;
  lastPrevState = prevState;
}

// ================= SENSOR READ TASK =================
void readSensorsTask() {
  unsigned long now = millis();

  if (now - lastSensorRead >= sensorInterval) {
    lastSensorRead = now;

    float newTemp = dht.readTemperature();
    float newHum = dht.readHumidity();

    if (!isnan(newTemp)) temp = newTemp;
    if (!isnan(newHum)) hum = newHum;

    airOutRaw = analogRead(MQ135_OUT);
    airInRaw = analogRead(MQ135_IN);

    airInPct = mapAirQuality(airInRaw, airInMin, airInMax);
    airOutPct = mapAirQuality(airOutRaw, airOutMin, airOutMax);
  }
}

// ================= AUTO LOGIC =================
void autoControlTask() {
  if (!autoMode) return;

  // Inside air range control
  if (airInPct > airHighPct) {
    setExfill(true);
  } 
  else if (airInPct < airLowPct) {
    setExfill(false);
  }

  // Outside air range control
  if (airOutPct > airHighPct) {
    setInfill(true);
  } 
  else if (airOutPct < airLowPct) {
    setInfill(false);
  }

  // Temperature range control
  if (temp > tempHigh) {
    openWindow();
  } 
  else if (temp < tempLow) {
    closeWindow();
  }
}

// ================= LCD PAGE DRAWERS =================
void drawPage0() {
  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print(autoMode ? "Mode:AUTO" : "Mode:MANUAL");

  lcd.setCursor(0, 1);
  lcd.print("T:");
  lcd.print(temp, 1);
  lcd.print("C H:");
  lcd.print(hum, 0);
  lcd.print("%");
}

void drawPage1() {
  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print("In Air: ");
  lcd.print(airInPct);
  lcd.print("%");

  lcd.setCursor(0, 1);
  lcd.print("Out Air:");
  lcd.print(airOutPct);
  lcd.print("%");
}

void drawPage2() {
  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print("W:");
  lcd.print(windowOpen ? "OPEN " : "CLOSE");
  lcd.print(" IN:");
  lcd.print(infillFan ? "ON" : "OFF");

  lcd.setCursor(0, 1);
  lcd.print("EXFILL:");
  lcd.print(exfillFan ? "ON " : "OFF");
}

void drawPage3() {
  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print("A:");
  lcd.print(airLowPct);
  lcd.print("-");
  lcd.print(airHighPct);
  lcd.print("%");

  lcd.setCursor(0, 1);
  lcd.print("T:");
  lcd.print(tempLow, 0);
  lcd.print("-");
  lcd.print(tempHigh, 0);
  lcd.print("C");
}

// ================= LCD TASK =================
void updateLCDTask() {
  unsigned long now = millis();

  if (showModeMessage) {
    if (now - modeMessageStart < modeMessageDuration) {
      lcd.setCursor(0, 0);
      lcd.print("                ");
      lcd.setCursor(0, 1);
      lcd.print("                ");

      lcd.setCursor(0, 0);
      lcd.print(modeMessage);
      lcd.setCursor(0, 1);
      lcd.print("Page ");
      lcd.print(currentPage + 1);
      return;
    } else {
      showModeMessage = false;
      lastDisplayedPage = -1;
    }
  }

  if (now - lastLCDUpdate >= lcdInterval) {
    lastLCDUpdate = now;

    switch (currentPage) {
      case 0: drawPage0(); break;
      case 1: drawPage1(); break;
      case 2: drawPage2(); break;
      case 3: drawPage3(); break;
    }

    lastDisplayedPage = currentPage;
  }
}

// ================= SERIAL TASK =================
void updateSerialTask() {
  unsigned long now = millis();

  if (now - lastSerialUpdate >= serialInterval) {
    lastSerialUpdate = now;

    Serial.println("===== SYSTEM STATUS =====");

    Serial.print("Mode: ");
    Serial.println(autoMode ? "AUTO" : "MANUAL");

    Serial.print("Page: ");
    Serial.println(currentPage + 1);

    Serial.print("Temp: ");
    Serial.print(temp);
    Serial.print(" C | Hum: ");
    Serial.print(hum);
    Serial.println(" %");

    Serial.print("Air IN Raw: ");
    Serial.print(airInRaw);
    Serial.print(" | %: ");
    Serial.println(airInPct);

    Serial.print("Air OUT Raw: ");
    Serial.print(airOutRaw);
    Serial.print(" | %: ");
    Serial.println(airOutPct);

    Serial.print("Window: ");
    Serial.println(windowOpen ? "OPENING/OPEN" : "CLOSING/CLOSED");

    Serial.print("Servo Current Pos: ");
    Serial.println(servoCurrentPos);

    Serial.print("Servo Target Pos: ");
    Serial.println(servoTargetPos);

    Serial.print("Infill Fan: ");
    Serial.println(infillFan ? "ON" : "OFF");

    Serial.print("Exfill Fan: ");
    Serial.println(exfillFan ? "ON" : "OFF");

    Serial.print("Air Range: ");
    Serial.print(airLowPct);
    Serial.print("% - ");
    Serial.print(airHighPct);
    Serial.println("%");

    Serial.print("Temp Range: ");
    Serial.print(tempLow);
    Serial.print(" C - ");
    Serial.print(tempHigh);
    Serial.println(" C");

    Serial.print("Humidity Threshold: ");
    Serial.print(humidityThreshold);
    Serial.println(" %");

    Serial.println("==========================\n");
  }
}

// ================= LOOP =================
void loop() {
  handleIR();
  handleButtons();
  readSensorsTask();
  autoControlTask();
  updateServoTask();
  updateLCDTask();
  updateSerialTask();
}